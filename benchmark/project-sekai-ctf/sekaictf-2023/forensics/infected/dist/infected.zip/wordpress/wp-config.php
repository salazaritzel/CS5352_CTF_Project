<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** Database username */
define( 'DB_USER', 'wordpress' );

/** Database password */
define( 'DB_PASSWORD', 'super_S3CUR3_mysql_P4s$w0rdd' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'S@n>8[jB6(wo0@M:DvIhX+!ay_]cS{H(!ZIMa`g6@G>,(:1{H46sp5pYdRHin|oQ');
define('SECURE_AUTH_KEY',  'kM+oBQ-+-S8d~3?+zEKIk${lJM 4M)5Wh[PPFlC+UocY<:=cj6%Aw^yngm~){@1R');
define('LOGGED_IN_KEY',    'o{pOCK ZG466`HP>Mu;%rI`Y|.Y|TFv%6-])Qgyr/t?8k[dT8ByV{L4>zVD$|yPz');
define('NONCE_KEY',        '#T*(Sblm7Dn1+HbAE2:/jO-@RkDfeJEsYY@=^-2c{ERI#EWZI3Ef@JYus,_(zBAc');
define('AUTH_SALT',        'z+mwp-6b[Q[Q3]SfgXhm ^ZmxFx-4E$MB=A9R&Ix}:u:OI1&)sX[-+W3sm>~Zq><');
define('SECURE_AUTH_SALT', 'N9d$!P1vr|s&S$yz$<W[%SFcCdmkae^i[7-)c1Dh:N{,{x[Q=+-t,*z_EY@#u!;U');
define('LOGGED_IN_SALT',   '?1j jG-,<tPoO6X2Eyj4gIkvxshR5xHCmTBaWe^6L~<W3=l<UB/B=jGe+i8[:D8,');
define('NONCE_SALT',       'JY|Q=5K+XC7~Q*<0H*1=BY#K*hZC ?|>IYqrxGYS}G@KUZ(:cq5]:E}Z3J/)+cS*');

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
